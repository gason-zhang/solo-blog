title: Centos 7.6 系统 nginx 安装
date: '2019-10-15 21:48:26'
updated: '2019-10-15 21:49:10'
tags: [Nginx]
permalink: /articles/2019/10/15/1571147305979.html
---
下载nginx安装包： wget http://nginx.org/download/nginx-1.16.1.tar.gz
解压安装包：tar -zxvf nginx-1.16.1.tar.gz
1.使用默认配置
./configure
2.自定义配置（不推荐）
```
./configure \
--prefix=/usr/local/nginx \
--conf-path=/usr/local/nginx/conf/nginx.conf \
--pid-path=/usr/local/nginx/conf/nginx.pid \
--lock-path=/var/lock/nginx.lock \
--error-log-path=/var/log/nginx/error.log \
--http-log-path=/var/log/nginx/access.log \
--with-http_gzip_static_module \
--with-http_ssl_module \
--http-client-body-temp-path=/var/temp/nginx/client \
--http-proxy-temp-path=/var/temp/nginx/proxy \
--http-fastcgi-temp-path=/var/temp/nginx/fastcgi \
--http-uwsgi-temp-path=/var/temp/nginx/uwsgi \
--http-scgi-temp-path=/var/temp/nginx/scgi \

```
编译安装
```
make
make install
```
